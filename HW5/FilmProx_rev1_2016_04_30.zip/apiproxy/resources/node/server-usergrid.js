var argo = require('argo');
var express = require('express');
var async = require("async");
var request = require('request'); 
var app = express();

/*var proxy = argo()
    .target('https://api.usergrid.com/madylil/sandbox/movies')
    .build();
  */  
var proxy = argo()
    .target('https://api.usergrid.com/madylil/sandbox/movies')
    .build();
var proxy = argo()
    .target('https://api.usergrid.com/madylil/sandbox/reviews')
    .build(); 

app.get('/help',function(req,res){
   request("I'm not sure how to fix this."); 
    
});

async.parallel([
    
        function(callback){
            
            //var url = "https://api.usergrid.com/madylil/sandbox/movies" + req.originalUrl; 
            var url = "https://api.usergrid.com/madylil/sandbox/movies"; 
            request(url, function (err,response,body) {
                
                if (err) { console.log(err); callback(true); return; }
                
                obj = JSON.parse(body); 
                
                callback(false,obj); //callback final
            });
        },
        
        function(callback) {
            
            //var url = "https://api.usergrid.com/madylil/sandbox/reviews" + req.originalUrl; 
            var url = "https://api.usergrid.com/madylil/sandbox/reviews";
            request(url,function (err,response,body) {
                
                if (err) { console.log(err); callback(true); return; }
                
                obj = JSON.parse(body); 
                
                callback(false,obj);//callback final
                
            });
        },
    
    ],
    
    function(err,results) {
        if(err) {console.log(err); res.send(500,"Severe Error on Server"); return;}
        
        res.send({api1:results[0],api2:results[1]}); 
        
        console.log(count); 
    });
    
app.get('/howdy',function(req,res){
   res.send({api1:results[0],api2:results[1]}); 
    
});    
    
    
app.post('/new', function(req, res) {
	if (!req.is('json')) {
		res.jsonp(400, {
			error : 'Bad request! Something is Missing Max'
		});
		return;
	}

	var b = req.body;
	var e = {
		'name' : b.name,
		'Actors' : [{'firstName' : b.firstName,'lastName' : b.lastName},
		            {'firstName' : b.firstName,'lastName' : b.lastName},
		            {'firstName' : b.firstName,'lastName' : b.lastName}],
		'year' : b.year
	};

	if ((e.name === undefined) || (e.firstName === undefined)
			|| (e.lastName === undefined) || (e.year === undefined)) {
		res.jsonp(400, {
			error : 'Bad request! Something was undefined Max'
		});
		return;
	}

	createProfile(e, req, res);
});

function createProfile(e, req, res) {
	var opts = {
		type : 'movies',
		name : e.name
	};

	client.createEntity(opts, function(err, o) {
		if (err) {
			res.jsonp(500, err);
			return;
		}
		o.set(e);
		o.save(function(err) {
			if (err) {
				res.jsonp(500, err);
				return;
			}
			res.send(201);
		});
	});
}


app.all('*', proxy.run);

app.listen(3000);