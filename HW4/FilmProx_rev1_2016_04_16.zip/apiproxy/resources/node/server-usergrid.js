var argo = require('argo');
var express = require('express');


var app = express();

var proxy = argo()
    .target('https://api.usergrid.com/madylil/sandbox/movies')
    .build();

app.get('/hello', function(req, res) {
    res.send('Hello from Express');
});

app.post('/new', function(req, res) {
	if (!req.is('json')) {
		res.jsonp(400, {
			error : 'Bad request! Something is Missing Max'
		});
		return;
	}

	var b = req.body;
	var e = {
		'name' : b.name,
		'Actors' : [{'firstName' : b.firstName,'lastName' : b.lastName},
		            {'firstName' : b.firstName,'lastName' : b.lastName},
		            {'firstName' : b.firstName,'lastName' : b.lastName}],
		'year' : b.year
	};

	if ((e.name === undefined) || (e.firstName === undefined)
			|| (e.lastName === undefined) || (e.year === undefined)) {
		res.jsonp(400, {
			error : 'Bad request! Something was undefined Max'
		});
		return;
	}

	createProfile(e, req, res);
});

function createProfile(e, req, res) {
	var opts = {
		type : 'movies',
		name : e.name
	};

	client.createEntity(opts, function(err, o) {
		if (err) {
			res.jsonp(500, err);
			return;
		}
		o.set(e);
		o.save(function(err) {
			if (err) {
				res.jsonp(500, err);
				return;
			}
			res.send(201);
		});
	});
}




app.all('*', proxy.run);

app.listen(3000);